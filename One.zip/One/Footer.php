 <div class="footer_top">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="footer_top_box">
            <div class="row">
              <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="footer_top_left"> <img src="images/1.jpg" alt="Footer Logo" />
                  <div class="ft_contact">
                    <h4>Contact</h4>
                    <address>
                    <p> <i class="fa fa-map-marker"></i></p>
                    <a href="tel:+100012354657"><i class="fa fa-phone"></i>Telephone – 071-527 7 527</a><br>
                    <a href="mail-to:Info@News.com"><i class="fa fa-phone"></i> E-mail  info@newsone.asia</a>
                    </address>
                  </div>
                  <div class="ft_connected">
                    <h4>Stay connected</h4>
                    <p>Follow us on social media and be up to date with the latest happenings.</p>
                    <ul>
                      <li><a class="fa fa-facebook" href="https://web.facebook.com/ONE-youtube-1st-1981796675367769/"></a></li>
                      <li><a class="fa fa-twitter" href=""></a></li>
                      <li><a class="fa fa-google-plus" href=""></a></li>
                      <li><a class="fa fa-linkedin" href=""></a></li>
                      <li><a class="fa fa-tumblr" href=""></a></li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="footer_top_right">
                  <div class="ftr_video">
                    <h4>video of the day</h4>
                    <div class="results_video embed-responsive embed-responsive-16by9">
                      <iframe class="embed-responsive-item" width="560" height="350" src="https://www.youtube.com/embed/LU1Xu1hGoSc" allowfullscreen></iframe>
                    </div>
                  </div>
                  <div class="ftr_tags">
                    <h4>Tags</h4>
                    <ul id="tag">
                      <li><a href="">දේශීය පුවත්</a></li>
                      <li><a href="">විදේශීය පුවත්</a></li>
                      <li><a href="">ක්‍රීඩා පුවත්‍</a></li>
                      <li><a href="">Apps and Software</a></li>
                      <li><a href="">Dev and Design</a></li>
                      <li><a href="">Gallery</a></li>
                      <li><a href="">Life and Style</a></li>
                      <li><a href="">Technology</a></li>
                      <li><a href="">Sports</a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="footer_bottom">
    <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="footer_bottom_box">
            <p> &copy; COPY RIGHTS 2017 All Rights Reserved. </p>
          </div>
        </div>
      </div>
    </div>
  </div>