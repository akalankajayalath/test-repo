<?php
 $conn=mysql_connect("localhost","root","");
 mysql_select_db("newsone");
 mysql_set_charset('utf8',$conn);
?>