<?php
 $conn=mysql_connect("localhost","news332211","news332211");
 mysql_select_db("newsone");
 mysql_set_charset('utf8',$conn);
?>