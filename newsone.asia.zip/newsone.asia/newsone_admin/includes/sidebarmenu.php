<div class="dashboard-nav">
		<div class="dashboard-nav-inner">

			<ul data-submenu-title="Main">
                <li><a href="dashboard.php"><i class="fa fa-dashboard"></i>Dashboard</a></li>
				<li><a href="Add_news.php"><i class="im im-icon-Newspaper-2"></i>News Add</a></li>
                <li><a href="video_add.php"><i class="im im-icon-Video"></i>Videos Add</a></li>
				<li><a href="edit.php"><i class="im im-icon-Newspaper"></i> Edit News</a></li>
                <li><a href=""><i class="fa fa-comments"></i>Comments Management</a></li>
				<li><a href=""><i class="fa fa-calendar-check-o"></i> .. </a></li>
			</ul>
		</div>
	</div>