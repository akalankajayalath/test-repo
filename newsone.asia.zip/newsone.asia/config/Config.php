<?php

//page url
$url="http://newsone.asia/";
?>